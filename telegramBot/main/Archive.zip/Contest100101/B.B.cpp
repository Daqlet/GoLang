URL: https://codeforces.com/gym/100101/submission/118700856 redirecting to the main page. Couldn`t find a code
Probably, the submission it private!